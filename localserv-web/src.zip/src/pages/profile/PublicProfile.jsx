import '../../styles/index.css';
import './publicprofile.css';
import { usePageBackdrop } from '../../hooks/usePageBackdrop';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import * as accountsApi from '../../api/accounts';
import * as chatApi from '../../api/chat';
import { useAuth } from '../../context/AuthContext';
import { ErrorAlert, Spinner } from '../../components/ui';
import { ReportButton } from '../../components/ReportButton';
import { ROLE_META } from '../../utils/roles';
import { lookFor } from '../../utils/bubbleLook';
import '../../components/age-glow.css';
import { ageGlowProps } from '../../utils/ageGroups';

export default function PublicProfile() {
  usePageBackdrop('couples');
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState(null);
  const [blocked, setBlocked] = useState(false);
  const [busy, setBusy] = useState(false);
  const [zoom, setZoom] = useState(false);

  useEffect(() => {
    accountsApi.getPublicProfile(id).then(setProfile).catch(setError);
  }, [id]);

  // Photo lightbox: Esc closes it and the page behind it stops scrolling.
  useEffect(() => {
    if (!zoom) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') setZoom(false); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev; };
  }, [zoom]);

  const handleMessage = async () => {
    setBusy(true);
    setError(null);
    try {
      const conversation = await chatApi.startConversation(id);
      navigate(`/chat/${conversation.id}`);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };

  const handleBlock = async () => {
    setBusy(true);
    setError(null);
    try {
      await accountsApi.blockUser(id);
      setBlocked(true);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };

  if (error) return <div className="page"><ErrorAlert error={error} onRetry={() => window.location.reload()} /></div>;
  if (!profile) return <div className="page"><Spinner /></div>;

  const isSelf = user?.id === profile.id;
  const name = profile.display_name || profile.username || 'Someone';
  const meta = ROLE_META[profile.role];
  const look = lookFor(profile.id, 0); // same colour and shape as their bubble in Find people

  return (
    <div className="page pf" style={{ '--tint': look.tint.bg, '--ring': look.tint.ring, '--avatar-shape': look.avatarShape }}>
      <header className="pf-hero" {...ageGlowProps(profile.age_range)}>
        <div className="pf-cover" aria-hidden="true" />
        <div className="pf-avatar-wrap">
          {profile.avatar ? (
            <button type="button" className="pf-avatar pf-avatar--btn" aria-label={`View ${name}'s photo full size`} aria-haspopup="dialog" onClick={() => setZoom(true)}>
              <img src={profile.avatar} alt="" />
            </button>
          ) : (
            <span className="pf-avatar"><span aria-hidden="true">{name[0].toUpperCase()}</span></span>
          )}
          {profile.online && <span className="pf-online" role="img" aria-label="Online" />}
        </div>
        <h1 className="pf-name">{name}</h1>
        <p className="pf-handle">@{profile.username}</p>
        <p className="pf-chips">
          {meta && <span className={`pf-chip pf-chip--${profile.role.toLowerCase()}`}>{meta.label}</span>}
          {profile.general_location && <span className="pf-chip">📍 {profile.general_location}</span>}
          {profile.availability && <span className="pf-chip">🕒 {profile.availability}</span>}
        </p>
        {meta && <p className="pf-blurb">{meta.blurb}</p>}
      </header>

      {profile.bio && (
        <section className="pf-card" aria-label="About">
          <h2>About</h2>
          <p className="break">{profile.bio}</p>
        </section>
      )}

      {!isSelf && user && !blocked && (
        <div className="pf-actions">
          <button type="button" className="pf-btn pf-btn--solid" disabled={busy} onClick={handleMessage}>👋 Message</button>
          <button type="button" className="pf-btn" disabled={busy} onClick={handleBlock}>Block</button>
          <ReportButton targetType="USER" targetId={profile.id} />
        </div>
      )}
      {!isSelf && user && !blocked && (
        <p className="text-sm muted" style={{ marginTop: 'var(--space-2)' }}>
          Blocking hides you from each other. You can unblock within 6 months; after that the block is permanent.
        </p>
      )}
      {zoom && profile.avatar && (
        <div className="pf-lightbox" role="dialog" aria-modal="true" aria-label={`${name}'s photo`} onClick={() => setZoom(false)}>
          <button type="button" className="pf-lightbox__close" aria-label="Close photo" autoFocus onClick={() => setZoom(false)}>×</button>
          <img className="pf-lightbox__img" src={profile.avatar} alt={`${name}'s photo`} onClick={(e) => e.stopPropagation()} />
        </div>
      )}
      {blocked && <p className="alert alert--info" style={{ marginTop: 'var(--space-4)' }}>You've blocked this user. You can undo it for 6 months from <Link to="/profile/blocked">Blocked people</Link>.</p>}
    </div>
  );
}
